# BlockPlacementAssist — Forge 1.20.1

Client-side practice helper for Minecraft Forge 1.20.1. While holding the use/place button with a block in the main hand, it softly adjusts the view toward the face of the block already under the crosshair. It does not place blocks automatically.

## Settings
- Press **O** to open the in-game settings screen.
- Adjust correction strength and smoothness, then press **Done** to save.
- Forge creates `config/blockplacementassist-client.toml` automatically.
- The assist only runs while the use/place button is held and a block is in the main hand.

Use only in single-player, private practice, or multiplayer environments where client-side assistance is permitted.
