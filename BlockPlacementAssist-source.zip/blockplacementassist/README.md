# Block Placement Assist (Forge 1.20.1)

A small client-side practice mod. While holding a placeable block and holding the use/place button, it gently smooths aim toward the center of the block face already under the crosshair. It does **not** automatically place blocks or find a target when the crosshair misses.

## Build

Requires Java 17 and internet access for Gradle to download Forge dependencies.

1. Download/extract the Forge MDK for Minecraft 1.20.1, or use this project with Gradle 8.x and the ForgeGradle plugin.
2. From this project directory run `gradle build` (or `./gradlew build` if you add the Gradle wrapper).
3. The jar will be in `build/libs/blockplacementassist-1.0.0.jar`.

## Install in ZalithLauncher

1. Launch the Minecraft 1.20.1 Forge profile once, then close the game.
2. Put the built `.jar` in that profile's `mods` folder.
3. Launch Forge 1.20.1 again.

## Tuning

In `ClientAssistHandler.java`:
- `STRENGTH = 0.10F`: smaller = gentler; try `0.05F` or `0.08F`.
- `REACH = 5.0D`: max distance to the targeted block for the assist.
- The yaw/pitch correction is capped to 2 degrees per tick.

This changes the camera slightly while placing. Test in a local world first. Multiplayer servers may prohibit aim-assist mods; follow the server rules.
