package com.example.blockplacementassist;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class ClientSettingsScreen extends Screen {
    private final Screen parent;
    private StrengthSlider strengthSlider;
    private SmoothnessSlider smoothnessSlider;

    public ClientSettingsScreen(Screen parent) {
        super(Component.translatable("screen.blockplacementassist.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int sliderWidth = Math.min(280, this.width - 40);
        int left = (this.width - sliderWidth) / 2;
        this.strengthSlider = new StrengthSlider(left, this.height / 2 - 38, sliderWidth, 20,
                ClientConfig.STRENGTH.get());
        this.smoothnessSlider = new SmoothnessSlider(left, this.height / 2 + 2, sliderWidth, 20,
                ClientConfig.SMOOTHNESS.get());
        this.addRenderableWidget(this.strengthSlider);
        this.addRenderableWidget(this.smoothnessSlider);
        this.addRenderableWidget(Button.builder(Component.translatable("gui.done"), button -> {
            ClientConfig.STRENGTH.set(this.strengthSlider.getSettingValue());
            ClientConfig.SMOOTHNESS.set(this.smoothnessSlider.getSettingValue());
            ClientConfig.SPEC.save();
            this.minecraft.setScreen(this.parent);
        }).bounds(left, this.height / 2 + 42, sliderWidth, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 90, 0xFFFFFF);
        graphics.drawCenteredString(this.font,
                Component.translatable("screen.blockplacementassist.hint"), this.width / 2,
                this.height / 2 - 67, 0xB0B0B0);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(this.parent);
    }

    private static final class StrengthSlider extends AbstractSliderButton {
        StrengthSlider(int x, int y, int width, int height, double setting) {
            super(x, y, width, height, Component.empty(), (setting - 0.01D) / 0.99D);
            updateMessage();
        }

        double getSettingValue() { return 0.01D + this.value * 0.99D; }

        @Override protected void updateMessage() {
            this.setMessage(Component.translatable("screen.blockplacementassist.strength", String.format("%.2f", getSettingValue())));
        }

        @Override protected void applyValue() { updateMessage(); }
    }

    private static final class SmoothnessSlider extends AbstractSliderButton {
        SmoothnessSlider(int x, int y, int width, int height, double setting) {
            super(x, y, width, height, Component.empty(), (setting - 0.01D) / 0.49D);
            updateMessage();
        }

        double getSettingValue() { return 0.01D + this.value * 0.49D; }

        @Override protected void updateMessage() {
            this.setMessage(Component.translatable("screen.blockplacementassist.smoothness", String.format("%.2f", getSettingValue())));
        }

        @Override protected void applyValue() { updateMessage(); }
    }
}
