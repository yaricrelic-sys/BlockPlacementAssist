package com.example.blockplacementassist;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;

@Mod(BlockPlacementAssist.MODID)
public class BlockPlacementAssist {
    public static final String MODID = "blockplacementassist";

    public BlockPlacementAssist() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
    }
}
