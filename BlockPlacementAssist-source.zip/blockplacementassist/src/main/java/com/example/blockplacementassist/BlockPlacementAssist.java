package com.example.blockplacementassist;

import net.minecraftforge.fml.common.Mod;

@Mod(BlockPlacementAssist.MODID)
public class BlockPlacementAssist {
    public static final String MODID = "blockplacementassist";

    public BlockPlacementAssist() {
        // Client tick handler is registered with Forge's event bus via @EventBusSubscriber.
    }
}
