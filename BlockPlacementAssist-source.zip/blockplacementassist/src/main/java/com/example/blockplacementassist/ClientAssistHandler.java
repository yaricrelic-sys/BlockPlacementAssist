package com.example.blockplacementassist;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Practice-oriented soft aim smoothing. It only runs while the player holds a placeable block,
 * holds the use/place button, and the crosshair already targets a block. It gently moves the
 * view toward the center of the face currently targeted; it does not place blocks automatically.
 */
@Mod.EventBusSubscriber(modid = BlockPlacementAssist.MODID, value = Dist.CLIENT)
public final class ClientAssistHandler {
    private static final double REACH = 5.0D;

    private ClientAssistHandler() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        if (!mc.options.keyUse.isDown()) return;
        if (!(mc.player.getMainHandItem().getItem() instanceof BlockItem)) return;
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        // Avoid changing aim when a block is too far away.
        if (mc.player.distanceToSqr(Vec3.atCenterOf(hit.getBlockPos())) > REACH * REACH) return;

        BlockPos pos = hit.getBlockPos();
        Direction face = hit.getDirection();
        Vec3 target = Vec3.atCenterOf(pos).add(
                face.getStepX() * 0.501D,
                face.getStepY() * 0.501D,
                face.getStepZ() * 0.501D
        );

        Vec3 eye = mc.player.getEyePosition();
        double dx = target.x - eye.x;
        double dy = target.y - eye.y;
        double dz = target.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) (Math.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        float targetPitch = (float) (-(Math.atan2(dy, horizontal) * (180.0D / Math.PI)));

        float yawDelta = Mth.wrapDegrees(targetYaw - mc.player.getYRot());
        float pitchDelta = Mth.wrapDegrees(targetPitch - mc.player.getXRot());

        // Keep it subtle and prevent large snap corrections.
        float maxStep = (float) (0.5D + ClientConfig.STRENGTH.get() * 7.5D);
        float smoothing = (float) ClientConfig.SMOOTHNESS.get();
        yawDelta = Mth.clamp(yawDelta, -maxStep, maxStep);
        pitchDelta = Mth.clamp(pitchDelta, -maxStep, maxStep);

        mc.player.setYRot(mc.player.getYRot() + yawDelta * smoothing);
        mc.player.setXRot(Mth.clamp(mc.player.getXRot() + pitchDelta * smoothing, -90.0F, 90.0F));
    }
}
