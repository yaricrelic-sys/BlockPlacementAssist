package com.example.blockplacementassist;

import net.minecraftforge.common.ForgeConfigSpec;

public final class ClientConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.DoubleValue STRENGTH;
    public static final ForgeConfigSpec.DoubleValue SMOOTHNESS;
    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.push("assist");
        STRENGTH = BUILDER.comment("Maximum correction angle strength. Higher values make the correction more noticeable.")
                .defineInRange("strength", 0.20D, 0.01D, 1.00D);
        SMOOTHNESS = BUILDER.comment("How much of the remaining angle is corrected per tick. Higher values react faster.")
                .defineInRange("smoothness", 0.10D, 0.01D, 0.50D);
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    private ClientConfig() {}
}
