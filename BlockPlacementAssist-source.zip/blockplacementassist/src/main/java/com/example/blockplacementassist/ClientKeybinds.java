package com.example.blockplacementassist;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = BlockPlacementAssist.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientKeybinds {
    public static final KeyMapping OPEN_SETTINGS = new KeyMapping(
            "key.blockplacementassist.settings", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_O,
            "key.categories.blockplacementassist");

    private ClientKeybinds() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN_SETTINGS);
    }

    @Mod.EventBusSubscriber(modid = BlockPlacementAssist.MODID, value = Dist.CLIENT)
    public static final class ClientEvents {
        private ClientEvents() {}

        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            while (OPEN_SETTINGS.consumeClick()) {
                if (mc.player != null) mc.setScreen(new ClientSettingsScreen(mc.screen));
            }
        }
    }
}
